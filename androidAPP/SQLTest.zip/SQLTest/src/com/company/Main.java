package com.company;


import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
// Packages to import
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.io.IOUtils;



class Restaurants{
    public String Name;
    public String VenueID;
    public String City;
    public String Address;
}

class Items{
    public String Name ;
    public String Description;
    public String Type ;
    public String Type2 ;
    public String Price ;
    public String ItemID ;
    public String VenueID ;
    public String Visible ;
}
class Customer{
    public String tableNo;
    public String telNo;
    public String venueID;
    public String status;
    public String timestamp;
}

class Order{
    public String itemID;
    public String comment;
    public String commentQty;
    public String quantity;

}

class CustomerOrder{
    public Customer customer;
    public ArrayList<Order> itemOrders ;

    public CustomerOrder(Customer Icustomer, ArrayList<Order> Iorder) {
        customer=Icustomer;
        itemOrders=Iorder;
    }
}

class Orders{
    public String TableNo;
    public String Comments;
    public String CommentQty;
    public String Name;
    public String OrderID;
    public String Status;
    public String Time;
    public String Bill;

}

class dbConnect extends TimerTask {
    private ArrayList<Restaurants> allRestaurants;
    private ArrayList<Items> itemsOfRestaurant;
    private ArrayList<Orders> allOrders;
    private String AvenueID = "1";
    //private JTableExamples table;

    @Override
    public void run() {
        try {
            retrieveOrders();
            //try{table.fire;} catch (NullPointerException e){e.printStackTrace();}

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public dbConnect() throws IOException {
        //table=parTable;
    }

    public dbConnect(String VenueID){
        AvenueID=VenueID;
    }



    public ArrayList<Restaurants> getRestaurants() throws IOException {
        URL url = new URL("https://ordercy.a2hosted.com/orderCY/getRestaurants.php");
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
        //System.out.println(body);
        Gson googleJson = new Gson();
        Restaurants[] javaArrayListFromGSON = googleJson.fromJson(body, Restaurants[].class);
        allRestaurants = new ArrayList<>(Arrays.asList(javaArrayListFromGSON));
        //System.out.println(allRestaurants.get(0).Name);

        return allRestaurants;

    }

    public ArrayList<Items> getItems(String venueID) throws IOException {
        String urlString = "https://ordercy.a2hosted.com/orderCY/getItems.php?venueID=" + URLEncoder.encode(venueID, StandardCharsets.UTF_8);
        URL url = new URL(urlString);
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
        Gson googleJson = new Gson();
        Items[] itemsjson = googleJson.fromJson(body, Items[].class);
        itemsOfRestaurant = new ArrayList<>(Arrays.asList(itemsjson));

        return itemsOfRestaurant;

    }


    public void submitOrder(CustomerOrder customerOrder) throws IOException {
        Gson gsonBuilder = new GsonBuilder().create();

        String customerJson = gsonBuilder.toJson(customerOrder.customer);
        String orderJson = gsonBuilder.toJson(customerOrder.itemOrders);
        String urlString = "https://ordercy.a2hosted.com/orderCY/insertOrder.php?order=" + URLEncoder.encode(customerJson, StandardCharsets.UTF_8)+ URLEncoder.encode(orderJson, StandardCharsets.UTF_8);
        URL url = new URL(urlString);
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);




    }

    public void retrieveOrders() throws IOException{
        if (AvenueID=="0") throw new IllegalArgumentException();
        String urlString = "https://ordercy.a2hosted.com/orderCY/getOrders.php?venueID=" + URLEncoder.encode(AvenueID, StandardCharsets.UTF_8);
        URL url = new URL(urlString);
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
        System.out.println(body);
        Gson googleJson = new Gson();
        Orders[] itemsjson = googleJson.fromJson(body, Orders[].class);
        allOrders = new ArrayList<>(Arrays.asList(itemsjson));
    }

    public ArrayList<Orders> getOrders() throws IOException {

        //retrieveOrders(venueID);
        if (AvenueID=="0") throw new IllegalArgumentException();
        return allOrders;
    }



}

class ViewOrders extends TimerTask{

    // frame
    public JFrame f;
    // Table
    public JTable j;

    public ArrayList<Orders> orders;
    private TimerTask connection;
    DefaultTableModel tbModel = new DefaultTableModel();

    public void clearTble(){
        for (int i = tbModel.getRowCount() - 1; i >= 0; i--) {
            tbModel.removeRow(i);
        }
    }

    public void refreshContents() throws IOException {
        clearTble();
        orders = ((dbConnect) connection).getOrders();
        for(int i=0; i<orders.size();i++ ){
            Object[] data = {   orders.get(i).TableNo,
                    orders.get(i).Comments,
                    orders.get(i).CommentQty,
                    orders.get(i).Name,
                    orders.get(i).OrderID,
                    orders.get(i).Bill,
                    orders.get(i).Status,
                    orders.get(i).Time};

            tbModel.addRow(data);
        }
        j = new JTable(tbModel);


    }

    // Constructor
    ViewOrders(String venueID) throws IOException {
        connection=connection = new dbConnect(venueID);
        //running timer task as daemon thread
        Timer timer2 = new Timer(true);
        timer2.scheduleAtFixedRate(connection, 0, 2*1000);

        // Frame initiallization
        f = new JFrame();

        // Frame Title
        f.setTitle("JTable Example");

        // Data to be displayed in the JTable

        // Column Names
        String[] columnNames = { "TableNo", "Comments", "Comments Qty", "Item Name", "OrderID", "Bill", "Status", "Time" };

        // Initializing the JTable


        tbModel.setColumnIdentifiers(columnNames);
        orders = ((dbConnect) connection).getOrders();
        //Insert data into table
        for(int i=0; i<orders.size();i++ ){
            Object[] data = {   orders.get(i).TableNo,
                                orders.get(i).Comments,
                                orders.get(i).CommentQty,
                                orders.get(i).Name,
                                orders.get(i).OrderID,
                                orders.get(i).Bill,
                                orders.get(i).Status,
                                orders.get(i).Time};

            tbModel.addRow(data);
        }
        j = new JTable(tbModel);

        j.setBounds(30, 40, 200, 300);

        // adding it to JScrollPane
        JScrollPane sp = new JScrollPane(j);
        f.add(sp);
        // Frame Size
        f.setSize(500, 200);
        // Frame Visible = true
        f.setVisible(true);
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);




    }

    @Override
    public void run() {
        try {
            refreshContents();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

public class Main
{

    public static void main(String args[]) throws IOException {

        //TESTING FOR COSTACIS
  /*      dbConnect connection = new dbConnect();

        System.out.println(connection.getItems("1").get(0).Type2);

        ArrayList<Order> orderArrayList = new ArrayList<Order>();

        Order order = new Order();
        order.itemID=connection.getItems(connection.getRestaurants().get(1).VenueID).get(0).ItemID;
        order.comment="sdfsd";
        order.commentQty="3";
        order.quantity="21";
        orderArrayList.add(order);

        Customer customer = new Customer();
        customer.tableNo="9";
        customer.telNo="99980779";
        customer.venueID=connection.getRestaurants().get(1).VenueID;

        CustomerOrder customerOrder = new CustomerOrder(customer,orderArrayList);
        connection.submitOrder(customerOrder);

*/

        //FOR VIEWING ORDERS ON DESKTOP. OF DIFFERENT RESTAURANTS JUST USE DIFERENT RESTAURANT VENUEID IN CONSTRUCTOR OF
        ViewOrders newtable = new ViewOrders(new dbConnect().getRestaurants().get(1).VenueID);


        Timer timer2 = new Timer(true);
        timer2.scheduleAtFixedRate(newtable, 0, 2*1000);

    }







}