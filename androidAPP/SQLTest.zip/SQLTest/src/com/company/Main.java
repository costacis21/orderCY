package com.company;


import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.io.IOUtils;



class Restaurants{
    public String Name;
    public String VenueID;
    public String City;
}

class Items{
    public String Name ;
    public String Description;
    public String Type ;
    public String Price ;
    public String ItemID ;
    public String VenueID ;
    public String Visible ;
}
class Customer{
    public String tableNo;
    public String telNo;
    public String venueID;
}

class Order{
    public String itemID;
    public String comment;
    public String commentQty;
    public String quantity;

        }

class CustomerOrder{
    public Customer customer;
    public ArrayList<Order> itemOrders ;

    public CustomerOrder(Customer Icustomer, ArrayList<Order> Iorder) {
        customer=Icustomer;
        itemOrders=Iorder;
    }
}

class dbConnect{
    private ArrayList<Restaurants> allRestaurants;
    private ArrayList<Items> itemsOfRestaurant;

    public dbConnect() throws IOException {

    }

    public ArrayList<Restaurants> getRestaurants() throws IOException {
        URL url = new URL("https://ordercy.a2hosted.com/orderCY/getRestaurants.php");
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
        //System.out.println(body);
        Gson googleJson = new Gson();
        Restaurants[] javaArrayListFromGSON = googleJson.fromJson(body, Restaurants[].class);
        allRestaurants = new ArrayList<>(Arrays.asList(javaArrayListFromGSON));
        //System.out.println(allRestaurants.get(0).Name);

        return allRestaurants;

    }

    public ArrayList<Items> getItems(String venueID) throws IOException {
        String urlString = "https://ordercy.a2hosted.com/orderCY/getItems.php?venueID=" + URLEncoder.encode(venueID, StandardCharsets.UTF_8);
        URL url = new URL(urlString);
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
        System.out.println(body);
        Gson googleJson = new Gson();
        Items[] itemsjson = googleJson.fromJson(body, Items[].class);
        itemsOfRestaurant = new ArrayList<>(Arrays.asList(itemsjson));

        return itemsOfRestaurant;

    }


    public void submitOrder(CustomerOrder customerOrder) throws IOException {
        Gson gsonBuilder = new GsonBuilder().create();

        String customerJson = gsonBuilder.toJson(customerOrder.customer);
        String orderJson = gsonBuilder.toJson(customerOrder.itemOrders);
        String urlString = "https://ordercy.a2hosted.com/orderCY/insertOrder.php?order=" + URLEncoder.encode(customerJson, StandardCharsets.UTF_8)+ URLEncoder.encode(orderJson, StandardCharsets.UTF_8);
        URL url = new URL(urlString);
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
        System.out.println(body);
        //System.out.println(urlString);



    }

}

public class Main
{

    public static void main(String args[]) throws IOException {
        dbConnect connection = new dbConnect();
        //connection.getRestaurants();
        //connection.getItems("1");

        ArrayList<Order> orderArrayList = new ArrayList<Order>();

        Order order = new Order();
        order.itemID=connection.getItems("1").get(0).ItemID;
        order.comment="sdfsd";
        order.commentQty="3";
        order.quantity="21";
        orderArrayList.add(order);

        Customer customer = new Customer();
        customer.tableNo="9";
        customer.telNo="99980779";
        customer.venueID="1";

        CustomerOrder customerOrder = new CustomerOrder(customer,orderArrayList);

        connection.submitOrder(customerOrder);

    }



}