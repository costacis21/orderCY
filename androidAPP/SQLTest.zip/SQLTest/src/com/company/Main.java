package com.company;


import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
// Packages to import
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.io.IOUtils;










public class Main
{

    public static void main(String args[]) throws IOException {


        Restaurants restaurants = new Restaurants();
        restaurants.run();
        Items items = new Items();
        items.run(restaurants.getAllRestaurants().get(1).VenueID);

        //TESTING FOR COSTACIS

        ArrayList<Order> orderArrayList = new ArrayList<Order>();

        Order order = new Order();
        order.itemID=items.getItemsOfRestaurant().get(0).ItemID;
        order.comment="sdfsd";
        order.commentQty="3";
        order.quantity="21";
        orderArrayList.add(order);

        Customer customer = new Customer();
        customer.tableNo="9";
        customer.telNo="99980779";
        customer.venueID=restaurants.getAllRestaurants().get(1).VenueID;

        CustomerOrder customerOrder = new CustomerOrder(customer,orderArrayList);
        customerOrder.run(customerOrder);

        System.out.println(items.getItemsOfRestaurant().get(1).Name);


        ViewOrders newtable = new ViewOrders(restaurants.getAllRestaurants().get(1).VenueID);


        Timer timer2 = new Timer(true);
        timer2.scheduleAtFixedRate(newtable, 0, 2*1000);

    }







}