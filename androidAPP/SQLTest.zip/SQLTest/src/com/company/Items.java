package com.company;

import com.google.gson.Gson;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;

class Item{
    public String Name ;
    public String Description;
    public String Type ;
    public String Type2 ;
    public String Price ;
    public String ItemID ;
    public String VenueID ;
    public String Visible ;
}


class Items extends Thread{
    private ArrayList<Item> itemsOfRestaurant;


    private void getItems(String venueID) throws IOException {
        String urlString = "https://ordercy.a2hosted.com/orderCY/getItems.php?venueID=" + URLEncoder.encode(venueID, StandardCharsets.UTF_8);
        URL url = new URL(urlString);
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
        Gson googleJson = new Gson();
        Item[] itemsjson = googleJson.fromJson(body, Item[].class);
        itemsOfRestaurant = new ArrayList<>(Arrays.asList(itemsjson));
    }




    public void run(String venueID) {
        try {
            getItems(venueID);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public ArrayList<Item> getItemsOfRestaurant(){
        return itemsOfRestaurant;
    }


}
