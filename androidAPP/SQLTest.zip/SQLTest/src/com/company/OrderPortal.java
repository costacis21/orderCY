package com.company;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.io.IOUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;





class Orders{
    public String TableNo;
    public String Comments;
    public String CommentQty;
    public String Name;
    public String OrderID;
    public String Status;
    public String Time;
    public String Bill;

}


class OrderPortal extends Thread{
    private ArrayList<Orders> allOrders;

    public OrderPortal(){
        
    }

    @Override
    public void run() {
        try {
            retrieveOrders();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }






    public void retrieveOrders() throws IOException{
        String urlString = "https://ordercy.a2hosted.com/orderCY/getOrders.php?venueID=" + URLEncoder.encode(AvenueID, StandardCharsets.UTF_8);
        URL url = new URL(urlString);
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
        System.out.println(body);
        Gson googleJson = new Gson();
        Orders[] itemsjson = googleJson.fromJson(body, Orders[].class);
        allOrders = new ArrayList<>(Arrays.asList(itemsjson));
    }

    public ArrayList<Orders> getOrders() throws IOException {

        //retrieveOrders(venueID);
        if (AvenueID=="0") throw new IllegalArgumentException();
        return allOrders;
    }



}

class ViewOrders extends TimerTask{

    // frame
    public JFrame f;
    // Table
    public JTable j;

    public ArrayList<Orders> orders;
    private TimerTask connection;
    DefaultTableModel tbModel = new DefaultTableModel();

    public void clearTble(){
        for (int i = tbModel.getRowCount() - 1; i >= 0; i--) {
            tbModel.removeRow(i);
        }
    }

    public void refreshContents() throws IOException {
        clearTble();
        orders = ((dbConnect) connection).getOrders();
        for(int i=0; i<orders.size();i++ ){
            Object[] data = {   orders.get(i).TableNo,
                    orders.get(i).Comments,
                    orders.get(i).CommentQty,
                    orders.get(i).Name,
                    orders.get(i).OrderID,
                    orders.get(i).Bill,
                    orders.get(i).Status,
                    orders.get(i).Time};

            tbModel.addRow(data);
        }
        j = new JTable(tbModel);


    }

    // Constructor
    ViewOrders(String venueID) throws IOException {
        connection=connection = new dbConnect(venueID);
        //running timer task as daemon thread
        java.util.Timer timer2 = new Timer(true);
        timer2.scheduleAtFixedRate(connection, 0, 2*1000);

        // Frame initiallization
        f = new JFrame();

        // Frame Title
        f.setTitle("JTable Example");

        // Data to be displayed in the JTable

        // Column Names
        String[] columnNames = { "TableNo", "Comments", "Comments Qty", "Item Name", "OrderID", "Bill", "Status", "Time" };

        // Initializing the JTable


        tbModel.setColumnIdentifiers(columnNames);
        orders = ((dbConnect) connection).getOrders();
        //Insert data into table
        for(int i=0; i<orders.size();i++ ){
            Object[] data = {   orders.get(i).TableNo,
                    orders.get(i).Comments,
                    orders.get(i).CommentQty,
                    orders.get(i).Name,
                    orders.get(i).OrderID,
                    orders.get(i).Bill,
                    orders.get(i).Status,
                    orders.get(i).Time};

            tbModel.addRow(data);
        }
        j = new JTable(tbModel);

        j.setBounds(30, 40, 200, 300);

        // adding it to JScrollPane
        JScrollPane sp = new JScrollPane(j);
        f.add(sp);
        // Frame Size
        f.setSize(500, 200);
        // Frame Visible = true
        f.setVisible(true);
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);




    }

    @Override
    public void run() {
        try {
            refreshContents();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




    public class OrderPortal {

    }
}
