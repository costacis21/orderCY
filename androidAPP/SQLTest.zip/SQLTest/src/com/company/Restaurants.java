package com.company;

import com.google.gson.Gson;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;

class Restaurant{
    public String Name;
    public String VenueID;
    public String City;
    public String Address;
}

class Restaurants extends Thread{


    private ArrayList<Restaurant> allRestaurants;

    private void getRestaurants() throws IOException {
        URL url = new URL("https://ordercy.a2hosted.com/orderCY/getRestaurants.php");
        URLConnection con = url.openConnection();

        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();

        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);

        Gson googleJson = new Gson();

        Restaurant[] javaArrayListFromGSON = googleJson.fromJson(body, Restaurant[].class);
        allRestaurants = new ArrayList<>(Arrays.asList(javaArrayListFromGSON));

    }


    @Override

    public void run() {
        try {
            getRestaurants();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public ArrayList<Restaurant> getAllRestaurants(){
        return allRestaurants;
    }
}
