package com.company;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

class Customer{
    public String tableNo;
    public String telNo;
    public String venueID;
    public String status;
    public String timestamp;
}

class Order{
    public String itemID;
    public String comment;
    public String commentQty;
    public String quantity;

}

class CustomerOrder extends Thread {
    public Customer customer;
    public ArrayList<Order> itemOrders;

    public CustomerOrder(Customer Icustomer, ArrayList<Order> Iorder) {
        customer = Icustomer;
        itemOrders = Iorder;
    }

    public void submitOrder(CustomerOrder customerOrder) throws IOException {
        Gson gsonBuilder = new GsonBuilder().create();

        String customerJson = gsonBuilder.toJson(customerOrder.customer);
        String orderJson = gsonBuilder.toJson(customerOrder.itemOrders);
        String urlString = "https://ordercy.a2hosted.com/orderCY/insertOrder.php?order=" + URLEncoder.encode(customerJson, StandardCharsets.UTF_8) + URLEncoder.encode(orderJson, StandardCharsets.UTF_8);
        URL url = new URL(urlString);
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
    }


    public void run(CustomerOrder customerOrder) {
        try {
            submitOrder(customerOrder);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}